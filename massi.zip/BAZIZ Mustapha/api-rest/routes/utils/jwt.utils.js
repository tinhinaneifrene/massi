// Importes les modules d'ont on a besoin 
var jwt = require('jsonwebtoken');
//signer notre token avec une constance 
const JWT_SIGN_SECRET = 'mousmousmousazerty';

// Exported les functions qui seront utils
module.exports = {
  generateTokenForUser: function(userData) {  //returner dans jwt une methode qui permet de signer notre token
    return jwt.sign({
        userId: userData.id,                  //recuperer l'identifiant de l'utilisateur .
        
    },
    JWT_SIGN_SECRET,                          //options pour parametrer notre token .
    {
        expireIn: '1h'                        //le oken ne serra plus valide au bout d'une heur .
    })
    }
}