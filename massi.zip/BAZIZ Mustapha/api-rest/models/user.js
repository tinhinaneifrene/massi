'use strict';
module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    email: DataTypes.STRING,
    username: DataTypes.STRING,
    password: DataTypes.STRING
  }, {});
  User.associate = function(models) {
    // les assiciations 
    models.User.hasMany(models.audio);
    models.User.hasMany(models.album);
  };
  return User;
};