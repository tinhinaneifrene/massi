'use strict';
module.exports = (sequelize, DataTypes) => {
  const album = sequelize.define('album', {
    idUsers: DataTypes.INTEGER,
    album_name: DataTypes.STRING
  }, {});
  album.associate = function(models) {
    // associations can be defined here
  };
  return album;
};